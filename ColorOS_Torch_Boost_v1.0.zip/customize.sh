# 刷入模块时的界面输出文字
ui_print "- 正在安装 ColorOS 手电筒提亮模块..."
ui_print "- 目标亮度：100 (默认四档为50)"
ui_print "- 核心逻辑：后台低耗电静默守护"
ui_print "- 支持设备：已测试 Color16 / ROOT设备"
ui_print "- 开发者：小杨大王"
ui_print "- 提示：请勿长时间开启手电筒，注意散热！"